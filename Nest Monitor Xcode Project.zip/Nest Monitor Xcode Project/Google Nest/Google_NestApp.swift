//
//  Google_NestApp.swift
//  Google Nest
//
//

import SwiftUI

@main
struct Google_NestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
